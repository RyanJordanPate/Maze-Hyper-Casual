// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Components/Button.h"
#include "GameFramework/GameModeBase.h"
#include "CRGameMode.generated.h"


/**
 * 
 */
UCLASS()
class HC_GAME_API ACRGameMode : public AGameModeBase
{
	GENERATED_BODY()

public:

	ACRGameMode();
	// Functions for the game flow and menus
	void EndGame();
	void LevelComplete();
	// void LevelCompleteMenu();
	UFUNCTION(BlueprintCallable)
	//void LoadNextLevel();
	
	// Function to remove the "UEDPIE_0" prefix from the Map Name when playing in the editor
	FString CleanLevelString(UObject* WorldContextObject);

protected:

	// WIDGETS

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "UMG")
	// "TSubClassOf" is a container for different class types, When this is exposed in the engine,
	//	only classes which are of type "UserWidget" can fill this property
	TSubclassOf<UUserWidget> DefaultLevelCompleteWidget;
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "UMG")
	UUserWidget* LevelCompleteWidget;
	
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "UMG")
	// "TSubClassOf" is a container for different class types, When this is exposed in the engine,
	//	only classes which are of type "UserWidget" can fill this property
	TSubclassOf<UUserWidget> DefaultGameCompleteWidget;
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "UMG")
	UUserWidget* GameCompleteWidget;
/*
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "UMG")
	// "TSubClassOf" is a container for different class types, When this is exposed in the engine,
	//	only classes which are of type "UserWidget" can fill this property
	TSubclassOf<UUserWidget> DefaultLevelCompleteMenuWidget;
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "UMG")
	UUserWidget* LevelCompleteMenuWidget;
*/
	// Timer for the amount time the level complete screen is shown and then swapped
	FTimerHandle LevelSwapTimer;

private:

	void BeginPlay() override;

	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, meta = (AllowPrivateAccess = true), Category = "Levels")
	// Array of level names which will be used to track what level the player is currently on
	TArray<FString> Levels;

	// UPROPERTY(EditAnywhere, BlueprintReadWrite, meta = (AllowPrivateAccess = true), Category = "Levels")
	// bool bNextLevelClicked;

	// Will be used to toggle the input modes
	APlayerController* Controller;

	// Int to track the current index in the array
	int32 CurrentLevelIndex;

	// The reference to the next level that will need to be loaded.
	FString NextLevel;

	// Function to check what current level the player is on
	void CheckLevel(); 
	
};
