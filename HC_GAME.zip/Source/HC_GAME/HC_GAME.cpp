// Fill out your copyright notice in the Description page of Project Settings.

#include "HC_GAME.h"
#include "Modules/ModuleManager.h"

IMPLEMENT_PRIMARY_GAME_MODULE( FDefaultGameModuleImpl, HC_GAME, "HC_GAME" );
