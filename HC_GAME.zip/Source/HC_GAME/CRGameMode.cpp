// Fill out your copyright notice in the Description page of Project Settings.


#include "CRGameMode.h"
#include "Blueprint/UserWidget.h"
#include "Kismet/GameplayStatics.h"


ACRGameMode::ACRGameMode()
{
    // Setting the current level to default at 0
	CurrentLevelIndex = 0;
}

void ACRGameMode::BeginPlay()
{
	Super::BeginPlay();
	// Set the reference to the variable Controller to the first player controller
	Controller = GetWorld() -> GetFirstPlayerController();
	// Local variable of type FInputModeGameOnly
	FInputModeGameOnly InputMode;
	// Setting the Input Mode to be Game Only so the player can get control of the pawn after using the Menus
	Controller -> SetInputMode(InputMode);
	// Removing mouse cursor which would be visible on the screen from the menus
	Controller -> bShowMouseCursor = false;
	// To see what level needs to begin
	CheckLevel();
	// bNextLevelClicked = false;
}

FString ACRGameMode::CleanLevelString(UObject* WorldContextObject)
{
	// Checking if there is access to "GEngine"
	if(GEngine)
	{
		// If there is access ->
		// Storing the prefix 
		FString Prefix = GEngine -> GetWorldFromContextObject(WorldContextObject) -> StreamingLevelsPrefix;
		// Getting the Level name which will have the prefix still attached
		FString LevelName = GetWorld() -> GetMapName();
		// Returning the level name but removing the length of the prefix from it.
		return LevelName.RightChop(Prefix.Len());
	}
	// If there is not access
	// Debug to say there isn't a map found 
	return "No Map Found due to Prefix";
}


void ACRGameMode::CheckLevel()
{
	// Getting the current map name and setting it to CurrentLevelName
	// OLD VARIABLE - FString CurrentLevelName = GetWorld() -> GetMapName();

	// Getting the level name from the "CleanLevelString" Function so there is no prefix added to the level name
	// allowing the gameplay loop to work correctly in the editor.
	FString CurrentLevelName = CleanLevelString(GetWorld());
	
	// Accessing the "Levels" array and finding the Current level name at the specified "CurrentIndex"
	Levels.Find(CurrentLevelName, CurrentLevelIndex);
	
	// If the Current level index is less than the amount of playable "Levels", run this
	if(CurrentLevelIndex < Levels.Num() - 1)
	{
		// Setting the Next level to be loaded, to be the next level in the array
		NextLevel = Levels[CurrentLevelIndex + 1];
	}
	// If the CurrentLevelIndex is more than the amount of levels in the array, run this
	else
	{
		// Setting the Next level to be loaded, to be the End screen
		NextLevel = "End";
	}
} 

void ACRGameMode::EndGame()
{
	// Local string variable "LevelString" used to store the current map name
	// OLD VARIABLE - GetWorld() -> GetMapName();
	FString LevelString = CleanLevelString(GetWorld());

	
	// Converting LevelString to a "FName", now able to pass the next level to load
	FName LevelToLoad = FName(*LevelString);

	// Using the imported Kismet GameplayStatics library to open the FName map stored in the variable "LevelToLoad" 
	UGameplayStatics::OpenLevel(this, LevelToLoad, true);
}

void ACRGameMode::LevelComplete()
{
	// Checking to see if "DefaultLevelCompleteWidget" exists and has a value inside of it
	if(DefaultLevelCompleteWidget)
	{
		// If true, setting LevelCompleteWidget to the creation of the "DefaultLevelCompleteWidget"
		LevelCompleteWidget = CreateWidget<UUserWidget>(GetWorld(), DefaultLevelCompleteWidget);
		// Adding the created widget to the viewport
		LevelCompleteWidget -> AddToViewport();
	}
	else
	{
		// Warning to let me know that there is no "DefaultLevelCompleteWidget" inside UE4 selected 
		UE_LOG(LogTemp, Warning, TEXT("No DefaultLevelCompleteWidget Selected"))
	}
	// Would now be entering back into a menu so now making the cursor visible again
	Controller -> bShowMouseCursor = true;
	// Making the input mode UI only so the player can interact with UI elements 
	FInputModeUIOnly InputMode;
	Controller -> SetInputMode(InputMode);
	
	// Timed break so the player will be able to read the level complete screen before loading to the next level
	// GetWorldTimerManager().SetTimer(LevelSwapTimer, this, &ACRGameMode::LevelCompleteMenu, 2.0f, false);
}

/*
void ACRGameMode::LevelCompleteMenu()
{
	if(DefaultLevelCompleteMenuWidget)
	{
	//	LevelCompleteWidget -> RemoveFromParent();
		LevelCompleteMenuWidget = CreateWidget<UUserWidget>(GetWorld(), DefaultLevelCompleteMenuWidget);
		LevelCompleteMenuWidget -> AddToViewport();
	}
	else
	{	
		UE_LOG(LogTemp, Warning, TEXT("No DefaultLevelSelectWidget Selected"))
	}
	

	if (bNextLevelClicked)
	{
		LoadNextLevel();
	}
}
*/




/*
void ACRGameMode::LoadNextLevel()
{
	// If the Levels array contains any of the in-game maps, then this will run
	if(Levels.Contains(NextLevel))
	{
		// Converting "NextLevel" to a FName so it can be loaded using the "OpenLevel()" function
		FName LevelToLoad = FName (*NextLevel);
		// Opening the level being held in "LevelToLoad"
		UGameplayStatics::OpenLevel(this, LevelToLoad, true);
	}
	// If there isn't anymore in-game maps left to run
	else
	{
		// Used to check if "LevelCompleteWidget" is left on the screen
		if(LevelCompleteWidget)
		{
			// Clears the widget from the screen
			LevelCompleteWidget -> RemoveFromParent();

			// Checking if "DefaultGameComplete" has a value stored
			if (DefaultGameCompleteWidget)
			{
				// If true, setting "GameCompleteWidget" to the creation of the "DefaultGameCompleteWidget"
				GameCompleteWidget = CreateWidget<UUserWidget>(GetWorld(), DefaultGameCompleteWidget);
				// Adding the created widget to the viewport
				GameCompleteWidget -> AddToViewport();

				// Would now be entering back into a menu so now making the cursor visible again
				Controller -> bShowMouseCursor = true;
				// Making the input mode UI only so the player can interact with UI elements 
				FInputModeUIOnly InputMode;
				Controller -> SetInputMode(InputMode);
			}
			else
			{
				// Warning to let me know that there is no "DefaultGameCompleteWidget" selected inside UE4 selected 
				UE_LOG(LogTemp, Warning, TEXT("No DefaultGameCompleteWidget Selected"))
			}
		}
			
	}
}

*/



