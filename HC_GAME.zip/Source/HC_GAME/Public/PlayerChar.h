// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Pawn.h"
#include "PlayerChar.generated.h"

UCLASS()
class HC_GAME_API APlayerChar : public APawn
{
	GENERATED_BODY()

public:
	// Sets default values for this pawn's properties
	APlayerChar();

	// Called every frame
	virtual void Tick(float DeltaTime) override;

	// Called to bind functionality to input
	virtual void SetupPlayerInputComponent(class UInputComponent* PlayerInputComponent) override;

protected:
	// Called when the game starts or when spawned
	virtual void BeginPlay() override;

	// UPROPERTIES
	// Creating the Character 
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Setup")
	UStaticMeshComponent* Sphere;

	// Implementing the main HUD for the player
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "UMG")
	TSubclassOf<UUserWidget> DefaultHUD;
	UUserWidget* HUD;

	
	
	// Creating Camera
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Setup")
	class USpringArmComponent* SpringArmComponent;
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Setup")
	class UCameraComponent* CameraComponent;

	// Floats for player movement
	UPROPERTY(EditAnywhere, Category = "Floats")
	float ForwardForce;
	UPROPERTY(EditAnywhere, Category = "Floats")
	float SideForce;

	// Vars
	class ACRGameMode* GameMode;
	bool bGameEnded;
	float Mass;
	float DeltaSeconds;
	bool bLevelWon;

	// New timer to have a short break before the EndGame function is called
	FTimerHandle EndGameTimer;

	// UFUNCTIONS
	UFUNCTION()
	void OnHit(UPrimitiveComponent * MyComp, AActor * Other, UPrimitiveComponent * OtherComp,
		FVector NormalImpulse, const FHitResult & Hit);
	UFUNCTION()
	void OnBeginOverlap(UPrimitiveComponent* OverlappedComponent, AActor* OtherActor,
		UPrimitiveComponent* OtherComp, int32 OtherBodyIndex, bool bFromSweep, const FHitResult &SweepResult);

	// Functions
	void GameEnded();
	void MoveRight(float AxisValue);
	void MoveForward(float AxisValue);
	void EndGame();
};
