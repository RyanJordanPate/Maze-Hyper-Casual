// Fill out you	r copyright notice in the Description page of Project Settings.

#include "HC_GAME/Public/PlayerChar.h"

#include "FinishLine.h"
#include "Obstacle.h"
#include "Blueprint/UserWidget.h"
#include "Camera/CameraComponent.h"
#include "Components/CapsuleComponent.h"
#include "GameFramework/SpringArmComponent.h"
#include "HC_GAME/CRGameMode.h"

// Sets default values
APlayerChar::APlayerChar()
{
 	// Set this pawn to call Tick() every frame.  You can turn this off to improve performance if you don't need it.
	PrimaryActorTick.bCanEverTick = true;

	// Creating all the Subobjects for the player character bp
	Sphere = CreateDefaultSubobject<UStaticMeshComponent>(TEXT("Player"));
	RootComponent = Sphere;

	// Creating Spring Arm
	SpringArmComponent = CreateDefaultSubobject<USpringArmComponent>(TEXT("SpringArm"));
	SpringArmComponent -> SetupAttachment(Sphere); // Attaching spring arm to mesh	

	// Creating Camera
	CameraComponent = CreateDefaultSubobject<UCameraComponent>(TEXT("Camera"));
	CameraComponent -> SetupAttachment(SpringArmComponent); // Attaching camera to the spring arm

	// Setting default values for the forward and lateral speed of the player character
	ForwardForce = 30;
	SideForce = 15;

	// Making the first player in the game possess this pawn class
	AutoPossessPlayer = EAutoReceiveInput::Player0;

	
}

// Called when the game starts or when spawned
void APlayerChar::BeginPlay()
{
	Super::BeginPlay();
	// Setting the Overlap and Hit events
	Sphere -> OnComponentHit.AddDynamic(this, &APlayerChar::OnHit);
	Sphere -> OnComponentBeginOverlap.AddDynamic(this, &APlayerChar::OnBeginOverlap);
	// Creating reference to the GameMode
	GameMode = Cast<ACRGameMode>(GetWorld()->GetAuthGameMode());

	// The game shouldn't be ended on start, so this is set to false
	bGameEnded = false;

	Sphere -> SetSimulatePhysics(true);
	// Getting the mass of the Player Character mesh and setting that to mass
	Mass = Sphere->GetMass();

	// Checking if DefaultHUD has been set in the BP
	if(DefaultHUD)
	{
		// Creating the Widget and then displaying it in game
		HUD = CreateWidget<UUserWidget>(GetWorld(), DefaultHUD);
		HUD -> AddToViewport();
	}
}

// Called every frame
void APlayerChar::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);

	// If game ended isn't true, run this
	if(!bGameEnded) 
	{
		// Setting the forward constant movement if the game isn't ended 
		// FVector Impulse = FVector(Mass * ForwardForce * DeltaTime, 0.0f, 0.0f);
		// Sphere->AddImpulse(Impulse); // Setting the player characters constant forward movement

		// Getting the Actors Location and setting this to a variable called ActorLoc
		FVector ActorLoc = GetActorLocation();
		// Seeing if the actor has fallen below -30 in the Z axis and if the level has been won or not
		if(ActorLoc.Z < -30 && bLevelWon == false)
		{
			GameEnded(); // If so the game will end
		}
	}
	// Passing DeltaTime into the variable DeltaSeconds For Framerate Independency 
	DeltaSeconds = DeltaTime;
}

// Called to bind functionality to input
void APlayerChar::SetupPlayerInputComponent(UInputComponent* PlayerInputComponent)
{
	Super::SetupPlayerInputComponent(PlayerInputComponent);

	// Binding Left and Right Movement
	PlayerInputComponent -> BindAxis("MoveRight", this, &APlayerChar::MoveRight);
	// Binding forward and backwards movement
	PlayerInputComponent -> BindAxis("MoveForward", this, &APlayerChar::MoveForward);
}

// When the character hits a obstacle, I want the game to end
void APlayerChar::OnHit(UPrimitiveComponent* MyComp, AActor* Other, UPrimitiveComponent* OtherComp,
	FVector NormalImpulse, const FHitResult& Hit)
{
	// Casting the obstacle class to "Other" granting the functionality to check if the obstacle has been hit
	AObstacle* Obstacle = Cast<AObstacle>(Other);
	// Checking if the cast has been successful
	if(Obstacle)
	{
		// If successful, End the game
		GameEnded();
	}
}

void APlayerChar::OnBeginOverlap(UPrimitiveComponent* OverlappedComponent, AActor* OtherActor,
	UPrimitiveComponent* OtherComp, int32 OtherBodyIndex, bool bFromSweep, const FHitResult& SweepResult)
{
	// Casting the finish line class to "OtherActor" granting the functionality to check if
	// the obstacle has been overlapped
	AFinishLine* LevelEnd = Cast<AFinishLine>(OtherActor);
	// Stopping the character from moving anymore
	ForwardForce = 0;
	SideForce = 0;
	// Setting bool to be true once the player has reached the finish line
	bLevelWon = true;
	// Checking if the cast has been successful
	if(LevelEnd)
	{
		// If successful, run the "LevelComplete()" function, which is found in the Game Mode class my_class {public:};
		GameMode -> LevelComplete();
	}
}

void APlayerChar::GameEnded()
{
	// If "bGameEnded" is true and "GameEnded()" is called, nothing should happen since the game should already be
	// ended, so just return 
	if(bGameEnded)
	{
		return;
	}
	// bGameEnded will be set true when "GameEnded()" is called
	bGameEnded = true;

	// Setting a 2 second timer before the EndGame function is called
	GetWorldTimerManager().SetTimer(EndGameTimer, this, &APlayerChar::EndGame, 2.0f, false);
}

void APlayerChar::EndGame()
{
	// Calling the EndGame function in the game-mode class to restart the level to the beginning
	GameMode -> EndGame();
}


void APlayerChar::MoveRight(float AxisValue)
{
	// Seeing if the game is ended. If it isn't, then the character will have movement on the Y axis
	if(!bGameEnded)
	{
		// Creating Movement on the Y-Axis
		FVector Impulse = FVector(0.0f,Mass * SideForce * DeltaSeconds * AxisValue, 0.0f);
		// Setting the Y-Axis movement to the player characters impulse.
		Sphere -> AddImpulse(Impulse,"", true);
	}
}


void APlayerChar::MoveForward(float AxisValue)	
{
	// Seeing if the game is ended. If it isn't, then the character will have movement on the X axis
	if(!bGameEnded)
	{
		// Creating Movement on the X-Axis
		FVector Impulse = FVector(Mass * ForwardForce * DeltaSeconds * AxisValue, 0.0f, 0.0f);
		// Setting the X-Axis movement to the player characters impulse.
		Sphere -> AddImpulse(Impulse,"", true); 
	}
			
}

